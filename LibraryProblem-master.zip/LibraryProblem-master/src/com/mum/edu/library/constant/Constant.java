package com.mum.edu.library.constant;

public class Constant {
	public static final String US_STATE_FILE = "database/stateUS.txt";
	public static final String MEMBER_FILE = "database/member.xml";
	public static final String BOOKS_FILE = "database/Books.xml";
	public static final String CHECKOUTRECORD_FILE = "database/CheckoutRecords.xml";
	
	public static final String RESOURCES = "resources";
	public static final String BIN = "bin";
	
	public static final String RESOURCE_MEMBER_CSS="manageMember.css";
}
